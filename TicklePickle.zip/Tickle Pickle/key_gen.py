# This code can be used to generate a new encryption/decryption key.

from cryptography.fernet import Fernet
key = Fernet.generate_key()
print(key)