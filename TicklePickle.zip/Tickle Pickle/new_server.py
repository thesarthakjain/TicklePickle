# We will read the data file and then decrypt it.

from cryptography.fernet import Fernet

#Decryption key and object
key = b'Ev8znykA0HDuNUwU46qjbHqNc9BO57N5Q2fLl1kMthE='
dec_obj=Fernet(key)

def reverse_fun():
    with open("users.json","rb") as f:
        data = f.read()
    
    #Decrypt the data.
    dec_text = dec_obj.decrypt(data)
    return(dec_text.decode())

if __name__ == '__main__':
      print(reverse_fun())